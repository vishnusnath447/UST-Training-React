const afterNYears = (obj,year)=>{
    // obj.reduce((sum,element)=>sum+element);
    return obj.map((element)=>{return(element.age+year)});
}


console.log(afterNYears([
    {
        name:"Joel",
        age : 32
    },
    {
        name:"Fred",
        age: 44
    },
    {
        name:"Reginald",
        age: 65
    },
    {
        name:"Susan",
        age: 33
    },
    {
        name:"Julian",
        age: 13
    }
], 5));